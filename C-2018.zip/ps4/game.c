
#include "command.h"

#include <stdio.h>
#include "game.h"



/**
 * Available game states
 */






/**
 * Starts game loop for the given game
 *
 * Main function of the game, which contains the game loop. So it's
 * responsible for reading the input from player, updating the state
 * of game and rendering the new situation.
 * @param game the game to be played
 */
void play_game(struct game* game) {
    printf("abrakadabra");
}



/**
 * Creates game
 *
 * Function creates game structure and returns it's reference.
 * But it will create not only the game structure, but also
 * initializes and creates all of it's members.
 * @return The created game object or NULL, if game could not be created.
 */
struct game* create_game()
{
    return NULL;
}


/**
 * Destroys game
 *
 * Destroys the game structure. With the destroying the game function
 * destroys also all of it's members. This function should be called
 * as the last, when the game is going to quit.
 * Function always returns NULL references as the new reference to
 * the game structure.
 * @param game the game to be destroyed
 * @return Always returns NULL
 */
struct game* destroy_game(struct game* game)
{
    return NULL;
}


/**
 * Executes command in the game
 *
 * Function executes the command given as the function parameter
 * on the game object. It doesn't return any value, but updates the
 * state of the game.
 * This function can be considered as the main function, which
 * contains the game logic.
 * @param game the game
 * @param command the command to be executed
 */
void execute_command(struct game* game, struct command* command)
{
    printf("abrakadabra");
}


