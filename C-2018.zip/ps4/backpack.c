
#include "item.h"
#include "container.h"
#include "backpack.h"
#include <string.h>
#include <stdlib.h>


struct backpack *create_backpack(const int capacity) {
    struct backpack *novyback = malloc(sizeof(struct backpack));
    novyback->capacity = capacity;
    novyback->size = 0;
    novyback->items = NULL;

    return novyback;
}


struct backpack *destroy_backpack(struct backpack *backpack) {


    free(backpack);
    return NULL;
}


bool add_item_to_backpack(struct backpack *backpack, struct item *item) {
    if(backpack == NULL) {
        return false;
    }
    if(item == NULL) {
        return false;
    }
    if(strcmp(item->name,"")==0){ return NULL;}
    if(strcmp(item->description,"")==0){ return NULL;}


    if(backpack->size < backpack->capacity) {
        backpack->items = create_container(backpack->items, ITEM, item);
        backpack->size++;
    }
    return true;
}


void delete_item_from_backpack(struct backpack *backpack, struct item *item) {
    struct item *newit = get_from_container_by_name(backpack->items,item->name);
    if (newit == NULL){

    }
    else
    {
        backpack->items=remove_container(backpack->items,item);
        backpack->size--;
    }


}


struct item *get_item_from_backpack(const struct backpack *backpack, char *name) {

    if (backpack == NULL){
        return NULL;
    }
    if (strcmp(backpack->items->item->name, "")==0){
        return NULL;
    }

    struct backpack* newback = (struct backpack *) backpack;
    while (newback->items!=NULL){


        if (strcmp(backpack->items->item->name, name) == 0) {
            return backpack->items->item;
        }
        newback->items = newback->items->next;

    }
    return NULL;
}

