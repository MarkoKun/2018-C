#include "container.h"

#include <stdlib.h>
#include <string.h>

struct container *create_container(struct container *first, enum container_type type, void *entry) {

    /*if (first == NULL)
    {
        return NULL;
    }*/
    if (strcmp(entry,"")==0)
    {
        return NULL;
    }
    

    struct container *new_container = malloc(sizeof(struct container));
    new_container->next = NULL;
    new_container->type = type;



    if (type == ROOM) {
        new_container->room = entry;
    }
    if (type == ITEM) {
        new_container->item = entry;
    }
    if (type == COMMAND) {
        new_container->command = entry;
    }
    if (type == TEXT) {
        new_container->text = entry;
    }

    if (first == NULL) {
        return new_container;
    }

    struct container *temp;
    temp = first;

    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = new_container;
    return first;
}

struct container *destroy_containers(struct container *first) {
    struct container *temp;
    if (first == NULL) {
        return NULL;
    }
    while (first != NULL) {
        temp = first->next;
        free(first);
        first = temp;
    }
    return NULL;
}


void *get_from_container_by_name(struct container *first, const char *name) {

    if (first == NULL)
    {
        return NULL;
    }
    if (strcmp(name,"")==0)
    {
        return NULL;
    }

    struct container *temp = first;
    while (temp != NULL) {

        if (temp->type == ROOM) {
            if (strcmp(name, temp->room->name) == 0) {
                return temp->room;
            }
        }
        if (temp->type == ITEM) {
            if (strcmp(name, temp->item->name) == 0) {
                return temp->item;
            }
        }
        if (temp->type == COMMAND) {
            if (strcmp(name, temp->command->name) == 0) {
                return temp->command;
            }
        }
        if (temp->type == TEXT) {
            if (strcmp(name, temp->text) == 0) {
                return temp->text;
            }
        }

        temp = temp->next;
    }
    return NULL;
}


/**
 * Deletes container, which holds given entry leaving the entry intact
 *
 * This function destroys only one container in the list. The container is
 * identified based on the pointer to the entry it contains. Content of the
 * container stays unchanged! Function returns reference to the beginning of
 * this list.
 * @param first pointer to the first container of the list
 * @param entry container entry
 * @return Reference to the list of containers without given container.
 */
struct container *remove_container(struct container *first, void *entry) {
    if(first == NULL)
    {
        return NULL;
    }



    struct container *temp = first;
    struct container* help;

    if(temp->type == ROOM)
    {
        if(temp->room == entry)
        {
            temp=first->next;
            free(first);
            return temp;
        }
    }


    if(temp->type == ITEM)
    {
        if(temp->item == entry)
        {
            temp=first->next;
            free(first);
            return temp;
        }
    }

    if(temp->type == COMMAND)
    {
        if(temp->command == entry)
        {
            temp=first->next;
            free(first);
            return temp;
        }
    }

    if(temp->type == TEXT)
    {
        if(temp->text == entry)
        {
            temp=first->next;
            free(first);
            return temp;
        }
    }






    while (temp->next != NULL) {


        if (temp->next->type == ROOM) {
            if(temp->next->room==entry){
                help = temp->next;
                temp->next = temp->next->next;
                free(help);
                return first;
            }
        }
        if (temp->next->type == ITEM) {
            if(temp->next->item==entry){
                help = temp->next;
                temp->next = temp->next->next;
                free(help);
                return first;
            }
        }
        if (temp->next->type == COMMAND) {
            if(temp->next->command==entry){
                help = temp->next;
                temp->next = temp->next->next;
                free(help);
                return first;
            }
        }
        if (temp->next->type == TEXT) {
            if(temp->next->text==entry){
                help = temp->next;
                temp->next = temp->next->next;
                free(help);
                return first;
            }
        }
        temp = temp->next;
    }
    return first;
}

