
#include <stdlib.h>

#include "container.h"

#include "parser.h"



struct parser* create_parser() {
    struct parser *novy = malloc(sizeof(struct parser));
    //novy->commands = NULL;
    novy->history = NULL;
    return novy;
}


struct parser* destroy_parser(struct parser *parser) {
    destroy_containers(parser->commands);
    destroy_containers(parser->history);
    free(parser);
    return NULL;
}


/**
 * Parses user input
 *
 * Function returns reference to the recognized command from the
 * user's input. If the parsering was not successful, function
 * returns NULL.
 * Parsing is not case sensitive, so the commands "Examine" and
 * "eXaMiNe" are same.
 * Parser is also resistant to the additional white characters.
 * So the input "    examine   chest   " parser examines correctly.
 * @param parser the parser
 * @param input string representing user's input
 * @return The reference to the recognized command or NULL, if input was not recognized successfully.
 */
struct command *parse_input(struct parser *parser, char *input){
    return NULL;
}



