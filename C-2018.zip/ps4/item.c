#include <malloc.h>
#include <string.h>
#include "item.h"

struct item* create_item(char* name, char* description, unsigned int properties)
{

    if(strcmp(name,"")==0)
    {
        return NULL;
    }
    if(strcmp(description,"")==0)
    {
        return NULL;
    }
    
    struct item* novy = malloc(sizeof(struct item));
    novy->name = malloc(sizeof(char) * strlen(name) + 1);
    novy->description = malloc(sizeof(char) * strlen(description) + 1);
    novy->properties = properties;

    strcpy(novy->name,name);
    strcpy(novy->description,description);

    return novy;
}



struct item* destroy_item(struct item* item){
    free(item->description);
    free(item->name);
    free(item);
    return NULL;
}
