#include "command.h"
#include <stdlib.h>
#include <memory.h>

struct command* create_command(char* name, char* description, char* pattern, size_t nmatch){
    if(strcmp(name,"")==0){
        return NULL;
    }
    if(strcmp(description,"")==0)
    {
        return NULL;
    }
    return NULL;
}
struct command* destroy_command(struct command* command){
    free(command);
    return NULL;
}