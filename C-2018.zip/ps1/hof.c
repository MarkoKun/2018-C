#include <stdio.h>
#include <string.h>

#include "hof.h"

int load( struct player list[] ) 
{
    FILE *score_file = fopen( "score", "r" );
	int i;
    if( score_file == NULL )
    {	
        return -1;
	}
    for( i = 0; i < 10; i++ )
    {
        if( fscanf( score_file, "%s %d", list[i].name, &list[i].score ) == EOF )
		{
		    break;
        }
	}

    for (int x = 0; x < i; x++)
    {
        for (int y = 0; y < i; y++)
        {
            if (list[y].score<list[y+1].score)
            {
                struct player temp = list[y+1];
                list[y+1]=list[y];
                list[y]=temp;
            }
        }
    }

    fclose( score_file );
    return i;
}

bool save(const struct player list[], const int size) 
{
    FILE *score_file = fopen( "score", "w" );
	int i;
    if( score_file == NULL )
    {
        return false;
	}
    for( i = 0; i < size; i++ )
    {
        fprintf( score_file, "%s %d\n", list[i].name, list[i].score );
	}
    fclose( score_file );
    return true;
}

bool add_player(struct player list[], int* size, const struct player player) 
{
    if (*size==10 && player.score>=list[*size-1].score){
        list[*size-1]=player;
    }else{
        list[*size]=player;
        *size+=1;
    }

    for (int i = *size-1; i >0 ; i--)
    {
        if (list[i].score>=list[i-1].score)
        {
            struct player temp = list[i-1];
            list[i-1]=list[i];
            list[i]=temp;
        }
    }

    save(list, *size);
    return true;
}