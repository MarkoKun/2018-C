#include <stdio.h>
#include <string.h>

#include "k.h"
#include "hof.h"
#include "ui.h"

int main() {
   
    

    struct game game = {
        .board = {
            {' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' '}
        },
        .score = 0
    };
    add_random_tile(&game);

    
    
}
    
