#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "k.h"

#define INVALID -1
#define EMPTY 32
#define number 64

void add_random_tile(struct game *game);
bool empty_tile(const struct game);

bool empty_tile(const struct game game){
    
    int row, col;

    for( row = 0; row < SIZE; row++ ) 
    {
        for( col = 0; col < SIZE; col++ ) 
        {
            if( game.board[row][col] == EMPTY )
            {
                return true;
            }
        }
    }

    return false;
}

void add_random_tile(struct game *game) {
    if ( empty_tile( *game ) == false )
        return;
    int row, col;
    // find random, but empty tile
    do{
        row = rand() % SIZE;
        col = rand() % SIZE;
    }while(game->board[row][col] != ' ');
    // place to the random position 'A' or 'B' tile
    if(rand() % 2 == 0){
        game->board[row][col] = 'A';
    }else{
        game->board[row][col] = 'B';
    }
}

bool is_game_won(const struct game game){
    int m, k;
    for( m = 0; m < SIZE; m++ )
    {
        for( k = 0; k < SIZE; k++ )
        {
            if( game.board[m][k] == 'K' )
                return true;
        }
    }
    return false;
}

bool is_move_possible(const struct game game){
    int i, j;
    for( i = 0; i < SIZE; i++ )
    {
        for( j = 0; j < SIZE; j++ )
        {
            if( game.board[i][j] == EMPTY)
                return true;
            if( i > 0 )
            {
                if ( game.board[i][j] == game.board[i - 1][j] )
                    return true;
            }
            if( j > 0 )
            {
                if( game.board[i][j] == game.board[i][j - 1])
                    return true;
            }
        }
    }   
    return false;
}

bool update(struct game *game, int dy, int dx){
    if(dx!=0&&dy!=0){
        return false; 
    }
    if(dx==1)
    {
        for (int y = 0; y < SIZE; y++)
        {
            for (int itt = 0; itt < SIZE-1; itt++)
            {
                for (int x = 0; x < SIZE-1; x++)
                {
                    if (game->board[y][x+1]==EMPTY)
                    {
                        int temp=game->board[y][x];
                        game->board[y][x]=game->board[y][x+1];
                        game->board[y][x+1]=temp;              
                    }
                }
            }
        }
        for (int i = 0; i < SIZE; i++)
        {
            if (game->board[i][0]==game->board[i][1] && game->board[i][1]!=EMPTY)
            {
                game->board[i][1]++;
                game->score=game->score+pow(2,game->board[i][1]-number);
                game->board[i][0]=' ';
            }
            if (game->board[i][2]==game->board[i][3] && game->board[i][3]!=EMPTY)
            {
                game->board[i][3]++;
                game->score=game->score+pow(2,game->board[i][3]-number);
                game->board[i][2]=' ';
            }
            if (game->board[i][1]==game->board[i][2] && game->board[i][2]!=EMPTY)
            {
                game->board[i][2]++;
                game->score=game->score+pow(2,game->board[i][2]-number);
                game->board[i][1]=' ';
            }
        }        
        for (int y = 0; y < SIZE; y++)
        {
            for (int itt = 0; itt < SIZE-1; itt++)
            {
                for (int x = 0; x < SIZE-1; x++)
                {
                    if (game->board[y][x+1]==EMPTY)
                    {
                        int temp=game->board[y][x];
                        game->board[y][x]=game->board[y][x+1];
                        game->board[y][x+1]=temp;              
                    }
                }
            }
        }
        return true;        
    }
    if(dy==1)
    {
        for (int x = 0; x < SIZE; x++)
        {
            for (int itt = 0; itt < SIZE-1; itt++)
            {
                for (int y = 0; y < SIZE-1; y++)
                {
                    if (game->board[y+1][x]==EMPTY)
                    {
                        int temp=game->board[y][x];
                        game->board[y][x]=game->board[y+1][x];
                        game->board[y+1][x]=temp;              
                    }
                }
            }
        }
        for (int i = 0; i < SIZE; i++)
        {
            if (game->board[0][i]==game->board[1][i] && game->board[1][i]!=EMPTY)
            {
                game->board[1][i]++;
                game->score=game->score+pow(2,game->board[1][i]-number);
                game->board[0][i]=' ';
            }
            if (game->board[2][i]==game->board[3][i] && game->board[3][i]!=EMPTY)
            {
                game->board[3][i]++;
                game->score=game->score+pow(2,game->board[3][i]-number);
                game->board[2][i]=' ';
            }
            if (game->board[1][i]==game->board[2][i] && game->board[2][i]!=EMPTY)
            {
                game->board[2][i]++;
                game->score=game->score+pow(2,game->board[2][i]-number);
                game->board[1][i]=' ';
            }
        }  
        for (int x = 0; x < SIZE; x++)
        {
            for (int itt = 0; itt < SIZE-1; itt++)
            {
                for (int y = 0; y < SIZE-1; y++)
                {
                    if (game->board[y+1][x]==EMPTY)
                    {
                        int temp=game->board[y][x];
                        game->board[y][x]=game->board[y+1][x];
                        game->board[y+1][x]=temp;              
                    }
                }
            }
        }
        return true;
    }
    if(dx==-1)
    {
        for (int y = 0; y < SIZE; y++)
        {
            for (int itt = 0; itt < SIZE-1; itt++)
            {
                for (int x = SIZE-1; x > 0; x--)
                {
                    if (game->board[y][x-1]==EMPTY)
                    {
                        int temp=game->board[y][x];
                        game->board[y][x]=game->board[y][x-1];
                        game->board[y][x-1]=temp;              
                    }
                }
            }
        }
        for (int i = 0; i < SIZE; i++)
        {
            if (game->board[i][0]==game->board[i][1] && game->board[i][1]!=EMPTY)
            {
                game->board[i][1]++;
                game->score=game->score+pow(2,game->board[i][1]-number);
                game->board[i][0]=' ';
            }
            if (game->board[i][2]==game->board[i][3] && game->board[i][3]!=EMPTY)
            {
                game->board[i][3]++;
                game->score=game->score+pow(2,game->board[i][3]-number);
                game->board[i][2]=' ';
            }
            if (game->board[i][1]==game->board[i][2] && game->board[i][2]!=EMPTY)
            {
                game->board[i][2]++;
                game->score=game->score+pow(2,game->board[i][2]-number);
                game->board[i][1]=' ';
            }
        }  
        for (int y = 0; y < SIZE; y++)
        {
            for (int itt = 0; itt < SIZE-1; itt++)
            {
                for (int x = SIZE-1; x > 0; x--)
                {
                    if (game->board[y][x-1]==EMPTY)
                    {
                        int temp=game->board[y][x];
                        game->board[y][x]=game->board[y][x-1];
                        game->board[y][x-1]=temp;              
                    }
                }
            }
        }
        return true;
    }
    if(dy==-1)
    {
        for (int x = 0; x < SIZE; x++)
        {
            for (int itt = 0; itt < SIZE-1; itt++)
            {
                for (int y = SIZE-1; y > 0; y--)
                {
                    if (game->board[y-1][x]==EMPTY)
                    {
                        int temp=game->board[y][x];
                        game->board[y][x]=game->board[y-1][x];
                        game->board[y-1][x]=temp;              
                    }
                }
            }
        }
        for (int i = 0; i < SIZE; i++)
        {
            if (game->board[0][i]==game->board[1][i] && game->board[1][i]!=EMPTY)
            {
                game->board[1][i]++;
                game->score=game->score+pow(2,game->board[1][i]-number);
                game->board[0][i]=' ';
            }
            if (game->board[2][i]==game->board[3][i] && game->board[3][i]!=EMPTY)
            {
                game->board[3][i]++;
                game->score=game->score+pow(2,game->board[3][i]-number);
                game->board[2][i]=' ';
            }
            if (game->board[1][i]==game->board[2][i] && game->board[2][i]!=EMPTY)
            {
                game->board[2][i]++;
                game->score=game->score+pow(2,game->board[2][i]-number);
                game->board[1][i]=' ';
            }
        } 
        for (int x = 0; x < SIZE; x++)
        {
            for (int itt = 0; itt < SIZE-1; itt++)
            {
                for (int y = SIZE-1; y > 0; y--)
                {
                    if (game->board[y-1][x]==EMPTY)
                    {
                        int temp=game->board[y][x];
                        game->board[y][x]=game->board[y-1][x];
                        game->board[y-1][x]=temp;              
                    }
                }
            }
        }
        return true;
    }
    return false;
}



