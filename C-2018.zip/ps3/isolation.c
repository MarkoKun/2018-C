#include<stdio.h>
#include<stdlib.h>

int main(int argc, char const *argv[])
{
    int magicnum = 1;
	printf("%d\n", magicnum);
	return 0;
}