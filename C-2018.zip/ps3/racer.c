#include<stdio.h>
#include<stdlib.h>







int main(int argc, char const *argv[])
{
	int num;
	double time;
	int temp = 2;
	
	scanf("%d %lf", &num, &time);
	
	double arr[num][temp];
	double returned = 0;
	int helpx = 0;
	int helpy = 0;
	int x =0;
	int y =0;
	while(x != num)
	{
		while(y < temp)
		{
			scanf("%lf",&arr[x][y]);
			
			y++;
		}
		

		x++;
	}
	

	while(helpx != num)
	{
		
		returned = (arr[helpx][helpy]/time)-(arr[helpx][helpy+1]);
		
		printf("%lf\n", returned);

		helpx++;
	}
	
	return 0;



}