#include<stdio.h>
#include<stdlib.h>







int main(int argc, char const *argv[])
{	
	int k = 0;
	int a,b;
	int magicnum = 1;
	double magic = 100;
	double mighty;
	scanf("%d %d", &a, &b);
	if (b == magicnum)
	{
		printf("%lf", magic);
	}
	
	if (b > magicnum)
	{
		mighty = magic/b;
		while(k < b)
		{
			printf("%lf\n", mighty);
			k++;
		}
	}
	return 0;



}