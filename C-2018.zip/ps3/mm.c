#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>
#include<stdint.h>


unsigned long long int mm(unsigned long long int num)
{
	int temp;
	unsigned long long int sum = 0;
	while(num)
	{
		temp=num%10;
		num=num/10;
		sum=sum+temp;
		//printf("num :%lld\n", num);
		//printf("temp :%d\n", temp);   
		//printf("sum :%lld\n", sum); 
		//printf("------------------\n");
  	}
  	if (sum >= 10)
    {   
    	unsigned long long int var=sum; 	
  		sum=mm(var);
    }
    
	return sum;

}
int main(int argc, char const *argv[])
{
	
	unsigned long long int numb=0;
	char pole;
	while((pole = getc(stdin)) != '\n')
	{
		//printf("pole :%c\n", pole);
		numb = numb+(pole - '0');
		//printf("numb :%lld\n", numb);
		//printf("------------------\n");
	}
	//printf("numb cele je :%lld\n", numb);
	
	printf("%lld\n", mm(numb));
}
	