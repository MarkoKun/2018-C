#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include "bmp.h"

char* reverse(const char* text){
    if(text != NULL) {
        size_t l = strlen(text);
        char* obratene = calloc(l + 1, 1);
        for(size_t i = l; i > 0; i--) {
            obratene[l-i] = (char) toupper(text[i-1]);
        }
        return obratene;
    }
    return NULL;
}

char* vigenere_encrypt(const char* key, const char* text){
    if (key == NULL) return NULL;
    if (text == NULL) return NULL;
    size_t l = strlen(key);
    size_t m = strlen(text);
    for(int i = 0; i < l; i++) if(isalpha(key[i]) == false) return NULL;

    char* sifrovane = calloc(m + 1, 1);
    if(sifrovane == NULL) return NULL;

    size_t kluc_poloha = 0;
    for(int index = 0; index < m; index++){
        if(isalpha(text[index])){
            int letter = toupper(text[index]) + toupper(key[kluc_poloha % strlen(key)]);
            letter %= 26;
            letter += 65;
            sifrovane[index] = (char) letter;
            kluc_poloha+=1;
        }else{
            sifrovane[index] = text[index];
        }
    }

    return sifrovane;
}

char* vigenere_decrypt(const char* key, const char* text){
    if (key == NULL) return NULL;
    if (text == NULL) return NULL;
    size_t l = strlen(key);
    size_t m = strlen(text);
    for(int i = 0; i < l; i++) if(isalpha(key[i]) == false) return NULL;

    char* desifrovane = calloc(strlen(text)+1, 1);
    if(desifrovane == NULL) return NULL;

    size_t kluc_poloha = 0;
    for(int index = 0; index < m; index++){
        if(isalpha(text[index])){
            if(toupper(text[index]) > toupper(key[kluc_poloha % strlen(key)])){
                int letter = toupper(text[index]) - toupper(key[kluc_poloha % strlen(key)]);
                letter += 65;
                if((char) toupper((char)letter) > 'Z'){
                    desifrovane[index] = (char) (toupper(letter) + 64 - 90);
                }else{
                    desifrovane[index] = (char) toupper(letter);
                }
            }else{
                int letter = toupper(text[index]) - toupper(key[kluc_poloha % strlen(key)]);
                letter += 91;
                if(toupper((char)letter) > (int)'Z'){
                    desifrovane[index] = (char) (toupper(letter) + 64 - 90);
                }else{
                    desifrovane[index] = (char) toupper(letter);
                }
            }
            kluc_poloha+=1;
        }else{
            desifrovane[index] = text[index];
        }
    }

    return desifrovane;
}

unsigned char* bit_encrypt(const char* text){
    if(text == NULL){
        return NULL;
    }

    
    int vstup[8] = {0};
    int vystup[8] = {0};

    unsigned char* sifrovane = calloc(strlen(text) + 1, 1);
    if(sifrovane == NULL){
        return NULL;
    }
    for(int i = 0; text[i] != '\0'; i++){
        int letter = (int) text[i];
        for(int j = 0; j < 8; j++){
            vstup[7-j] = letter % 2;
            letter /= 2;
        }
        for(int j = 0; j < 4; j+=2){
            vystup[j] = vstup[j+1];
            vystup[j+1] = vstup[j];
        }
        for(int j = 4; j < 8; j++){
            vystup[j] = vystup[j-4] ^ vstup[j];
        }
        letter = 0;
        for(int j = 0; j < 7; j++){
            letter = letter | vystup[j];
            letter = letter << 1;
        }
        letter = letter | vystup[7];
        sifrovane[i] = (unsigned char) letter;
    }
    
    return sifrovane;
}

char* bit_decrypt(const unsigned char* text){
    if(text == NULL){
        return NULL;
    }

    int vstup[8] = {0};
    int vystup[8] = {8};
    char* desifrovane = calloc(strlen((char*)text) + 1, 1);
    if(desifrovane == NULL) return NULL;

    for(int i = 0; text[i] != '\0'; i++){
        int letter = (int) text[i];
        for(int j = 0; j < 8; j++){
            vstup[7-j] = letter % 2;
            letter /= 2;
        }
        for(int j = 0; j < 4; j+=2){
            vystup[j] = vstup[j+1];
            vystup[j+1] = vstup[j];
        }
        for(int j = 4; j < 8; j++){
            vystup[j] = vystup[j];
        }
        for(int j = 4; j < 8; j++){
            vystup[j] = vstup[j-4] ^ vstup[j];
        }
        letter = 0;
        for(int j = 0; j < 7; j++){
            letter = letter | vystup[j];
            letter = letter << 1;
        }
        letter = letter | vystup[7];
        desifrovane[i] = (char) letter;
    }
    
    return desifrovane;
}

char* bmp_decrypt(const char* key, const unsigned char* text){
    if(key == NULL || text == NULL) return NULL;

    char* desifrovane = bit_decrypt(text);
    if(desifrovane == NULL) return NULL;

    char* desifrovane2 = vigenere_decrypt(key, (const char*) desifrovane);
    free(desifrovane);
    if(desifrovane2 == NULL) return NULL;

    char* vystup = reverse((const char*) desifrovane2);
    free(desifrovane2);
    return vystup;
}

unsigned char* bmp_encrypt(const char* key, const char* text){
    if(key == NULL) return NULL; 
    if(text == NULL) return NULL;

    char* obratene = reverse(text);
    if(obratene == NULL) return NULL;

    char* sifrovane = vigenere_encrypt(key, (const char*) obratene);
    free(obratene);
    if(sifrovane == NULL) return NULL;

    unsigned char* vystup = bit_encrypt((const char*) sifrovane);
    free(sifrovane);
    return vystup;
}
