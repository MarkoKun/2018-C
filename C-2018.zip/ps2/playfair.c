#include <string.h>
#include <stdlib.h>
#include <ctype.h>

char* playfair_encrypt(const char* key, const char* text){
    if(key == NULL || text == NULL) return NULL;
    for(int c=0; c < strlen(text); c++) if(text[c] != ' ' && !isalpha(text[c])) return NULL;
    for(int c=0; c < strlen(key); c++) if(!isalpha(key[c])) return NULL;
    char* vystup = calloc(10, sizeof(char));
    return vystup;
}

char* playfair_decrypt(const char* key, const char* text){
    if(key == NULL || text == NULL) return NULL;
    for(int c=0; strlen(text); c++) if(!isalpha(text[c]) && text[c] != ' ') return NULL;
    for(int c=0; strlen(text); c++) if(text[c] == 'W') return NULL;
    for(int c=0; key[c] != '\0'; c++) if(!isalpha(key[c])) return NULL;
    char* vystup = calloc(10, sizeof(char));
    return vystup;
}
