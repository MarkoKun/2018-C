#include <Arduino.h>
#include "mastermind.h"
#include "lcd_wrapper.h"

#include <stdlib.h>
#include <string.h>

/* Definovanie hodnot, kedy su LEDky zapnute a vypnute. Zalezi od
   typu pouzitych LEDiek. */
#define ON  LOW
#define OFF HIGH

/* Funkcia na overenie, ci sa v retazci input nachadza pismeno letter.
 * Ak sa nachadza pismeno v retazci vrati sa hodnota true, v opacnom
 * pripadesa vrati hodnota false. */
bool check_occurance(char* input, int length, char letter) {
  /* Prechod retazcom znak po znaku. */
  for(int index = 0; index < length; index++) {
    if(input[index] == letter)
      return true;
  }

  return false;
}

char* generate_code(bool repeat, int length) {
  /* Overovanie vstupu:
   * dlzka nesmie byt menej ako 1,
   * ak je dlzka vacsia ako 10, repeat nesmie byt false. 
   */
  if(length < 1 || (length > 10 && repeat == false))
    return NULL;

  /* Alokacia pamata pre vysledok, +1 sa dava kvoli terminatoru. */
  char* result = (char*) malloc(length + 1);

  /* Cyklus generuje nahodne cisla, ktore potom vklada do vysledneho retazca. */
  for(int index = 0; index < length; index++) {
    /* Generovanie nahodneho cisla od 0 do 9, pricom pripocitame hodnotu
       cisla 0 v ASCII tabulke, aby sme dostali ASCII hodnotu daneho cisla. */
    char random_number = random(10) + '0';

    /* Ak nie je povolene opakovanie znakov, overi sa, ci dany znak sa nachadza
       vo vyslednom retazci. V pripade, ze sa nachadza, generuje sa nove cislo. */
    if(repeat == false) {
      while(check_occurance(result, index, random_number) == true) {
        random_number = random(10) + '0';
      }
    } 

    /* Zapis novo vygenerovaneho znaku do vysledneho retazca. */
    result[index] = random_number;
  }

  /* Pridanie terminatora na koniec vysledneho retazca. */
  result[length] = '\0';

  /* Vratenie finalneho retazca. Treba vsak uvolnit pamat po jeho pouziti. */
  return result;
}

void get_score(const char* secret, const char* guess, int* peg_a, int* peg_b) {
  /* Nastavenie vyslednych hodnot na nulu. */
  *peg_a = 0;
  *peg_b = 0;
  
  /* Alokacia pamate, do ktorej sa zapisu znaky, ktore sa nezhoduju v secret
     a guess na rovnakej pozicii. */
  char* not_matching = (char*) malloc(strlen(guess));

  /* Cyklus prejde cely retazec secret a spocita vsetky znaky, ktore sa zhoduju
   * v retazci guess na tej istej pozicii. Ak sa zhoduju, do not_matching sa zapise
   * hodnota 0, v opacnom pripade samotny znak z retazca guess. */
  for(int index = 0; index < strlen(secret); index++) {
    if(secret[index] == guess[index]) {
      (*peg_a)++;
      not_matching[index] = 0;
    } else {
      not_matching[index] = guess[index];      
    }
  }

  /* Cyklus prejde cely retazces secret, pricom spocita vsetky znaky, ktore sa
   * sa zhoduju v retazci not_matching na hocijakej pozicii. Ak sa najde zhoda,
   * dany znak v retazci not_matching sa nahradi 0, aby sa pri neskorsom poro-
   * vnani nezapocital. */
  for(int index = 0; index < strlen(secret); index++) {
    for(int tmp_idx = 0; tmp_idx < strlen(secret); tmp_idx++) {
      if(secret[index] == not_matching[tmp_idx] && secret[index] != guess[index]) {
        (*peg_b)++;
        not_matching[tmp_idx] = 0;
        break;
      }
    }
  }

  /* De-alokacia pamata, ktoru zaberal retazec not_matching. */
  free(not_matching);
}

void turn_off_leds() {
  /* Cyklus prejde, kazdy pin a nastavi jeho hodnotu na OFF. OFF je definovany na 
     zaciatku tohto suboru a treba ho nastavit podla toho, aky typ diody pouzivame. */
  for(int index = LED_BLUE_1; index <= LED_RED_4; index++) {
    digitalWrite(index, OFF);    
  }
}

void render_leds(const int peg_a, const int peg_b) {
  /* Premenna obsahuje zlomovy pin. Do tohto pinu svietia vsetky LEDky na cerveno,
     dalej budu LEDky svietit na modro, alebo vobec. */
  int border = LED_BLUE_1 + (peg_a * 2);
  
  /* Zapnutie cervenych LEDiek. */
  for(int index = LED_BLUE_1; index < border; index += 2) {
    digitalWrite(index, OFF);
    digitalWrite(index + 1, ON);
  }
  
  /* Zapnutie modrych LEDiek. */
  for(int index = border; index < border + (peg_b * 2); index += 2) {
    digitalWrite(index, ON);
    digitalWrite(index + 1, OFF);   
  }
}

void render_history(char* secret, char** history, const int entry_nr) {
  int peg_a, peg_b;
  /* Ziskanie hodnot peg_a a peg_b. */
  get_score(secret, history[entry_nr], &peg_a, &peg_b);

  /* Vypis na obrazovku v tvare:
   *  entry_nr:history[entry_nr] A:peg_a B:peg_b
   *  
   *  Priklad:
   * ╔═════════╗
   * ║3: 1337 A:1 B:3║
   * ║               ║
   * ╚═════════╝
   *   
   */
  /* Premenna, do ktorej sa budu ukladat cisla, aby ich bolo mozne vypisat ako char* */
  char tmp_str[2];
  /* Pridanie terminatora. Terminator sa nikdy nebude menit, kedze sa vypisuju iba
     jednociferne cisla. */
  tmp_str[1] = '\0';

  tmp_str[0] = entry_nr + '0' + 1;
  
  lcd_print_at(0, 0, tmp_str);  
  lcd_print(": ");
  lcd_print(history[entry_nr]);

  tmp_str[0] = peg_a + '0';
   
  lcd_print(" A:");
  lcd_print(tmp_str);

  tmp_str[0] = peg_b + '0';
  
  lcd_print(" B:");
  lcd_print(tmp_str);

  /* Vypnutie LEDiek, aby si neboli zapnute take, ktore nemaju byt zapnute. */
  turn_off_leds();
  
  /* Rozvietenie LEDiek podla peg_a a peg_b. */
  render_leds(peg_a, peg_b);
}

void play_game(char* secret) {
  /* Deklaracia premennych, ktore budu uchovavat stav tlacidiel. */
  int btn_ent, btn_1, btn_2, btn_3, btn_4;

  /* Premenna obsahujuca celu historiu a pomocna premenna obsahujuca
   * pocet poloziek v historii. */
  char* history[11];
  int history_count = 0;

  /* Premenna ukazujuca na polozka, ktora sa ma vypisat. */
  int history_point = 0;

  /* Herna slucka. Dokym je repeat true, hra pojde stale dookola. */
  while(true) {
    /* Vypis uvodnej obrazovky. */
    lcd_clear();
  
    lcd_print_at(0, 3, "Welcome to");
    lcd_print_at(1, 3, "MASTERMIND");
  
    delay(2000);
    
    /* Vypis zaciatku hry */
    lcd_clear();
    lcd_print_at(0,0, "Enter your guess");

    /* Premenna udavajuca, ci je hra dokoncena. */
    bool finished = false;

    /* Slucka hry. Ak je hra vyhrata/prehrata slucka konci. */
    while(finished == false) {
      /* Nastavenie history_point ak uz existuje zaznam v history_count. */
      if(history_count > 0) {
        history_point = history_count - 1;
        
        /* Renderovanie historie, v tomto pripade posledneho pokusu. */
        render_history(secret, history, history_point);
      }
      
      /* Vytvorenie retazca guess, v ktorom bude momentalny tip
       * uzivatela. Na zaciatku nastavime vsetky znaky rovne '0'. 
       * Taktiez pridame terminator na koniec retazca. */
      char* guess = (char*) malloc(strlen(secret) + 1);
      memset(guess,'0', strlen(secret));
      guess[strlen(secret)] = '\0';
  
      /* Premenna udava, ci bol stlaceny button reprezentujuci ENTER. */
      bool enter = false;
  
      /* Slucka, ktora caka dokym uzivatel nastavi nastavi pozadovane
         hodnoty a stlaci ENTER. */
      while(enter == false) {
        /* Nacitanie vstupu z tlacidiel. */
        btn_ent = digitalRead(BTN_ENTER_PIN);
        btn_1 = digitalRead(BTN_1_PIN);
        btn_2 = digitalRead(BTN_2_PIN);
        btn_3 = digitalRead(BTN_3_PIN);
        btn_4 = digitalRead(BTN_4_PIN);   
  
        /* Overanie stlacenych tlacidiel. */
        if(btn_ent == HIGH) {
          /* Cakanie, dokym uzivatel pusti tlacidlo. */
          while(digitalRead(BTN_ENTER_PIN) == HIGH) {
            delay(10);
          }
          
          enter = true;
        }
        else if(btn_1 == HIGH && btn_3 == HIGH) {
          /* Nastavenie history pointu na pozadovanu hodnotu. */
          if(history_point > 0) {
            history_point--;
          } else {
            history_point = history_count - 1;            
          }

          /* Overenie ci history_point ma pouzitelnu hodnotu, vtedy nema
           * ak je history_count 0. Ak je hodnota pozuitelna renderuje sa
           * historia, na ktoru ukazuje history_point. */
          if(history_point >= 0) {
            render_history(secret, history, history_point);
          }
        }
        else if(btn_1 == HIGH && btn_2 == HIGH) {
          /* Nastavenie history pointu na pozadovanu hodnotu. */
          if(history_point < history_count - 1) {
            history_point++;
          } else {
            history_point = 0;            
          }

          /* Overenie ci history_point ma pouzitelnu hodnotu, vtedy nema
           * ak je history_count 0. Ak je hodnota pozuitelna renderuje sa
           * historia, na ktoru ukazuje history_point. */
          if(history_count > 0) {
            render_history(secret, history, history_point);
          }
        }
        else if(btn_1 == HIGH) {
          /* Priradenie dalsej hodnoty do guess, ale aby si mohli cyklit znaky
          *  znaky medzi '0' a '9' pouzijeme tento vyraz pre vsetky dalsie. */
          guess[0] = ((guess[0] - '0' + 1) % 10) + '0';

          while(digitalRead(BTN_1_PIN) == HIGH) {
            delay(10);
          }
        }
        else if(btn_2 == HIGH) {
          guess[1] = ((guess[1] - '0' + 1) % 10) + '0';

          while(digitalRead(BTN_2_PIN) == HIGH) {
            delay(10);
          }
        }
        else if(btn_3 == HIGH) {
          guess[2] = ((guess[2] - '0' + 1) % 10) + '0';

          while(digitalRead(BTN_3_PIN) == HIGH) {
            delay(10);
          }
        }
        else if(btn_4 == HIGH) {
          guess[3] = ((guess[3] - '0' + 1) % 10) + '0';

          while(digitalRead(BTN_4_PIN) == HIGH) {
            delay(10);
          }
        }
        
        lcd_print_at(1, 0, guess);
        delay(100);
      }

      lcd_clear();
      
      /* Zapis pokusu do historie. */
      history[history_count] = guess;
      history_count++;

      /* Podmienka ak uzivatel vyhral. */
      if(strcmp(secret, guess) == 0) {
        lcd_print_at(0, 4, "YOU WON!");
        lcd_print_at(1, 0, " Tips needed: ");

        /* Ak je pocet pokusovat vacsi ako 9, teda je to dvojciferne cislo, treba vacsi retazec
        *  spravny vypis. */
        if(history_count > 9) {
          /* Premenna, do ktorej sa budu ukladat cisla, aby ich bolo mozne vypisat ako char* */
          char tmp_str[3];
          /* Pridanie terminatora. */
          tmp_str[2] = '\0';
          /* Zapis prvej cifry cisla cisla do retazca. */
          tmp_str[0] = (history_count / 10) + '0';
          tmp_str[1] = (history_count % 10) + '0';
          
          lcd_print(tmp_str);
          lcd_print(" tip");
        } else {
          /* Premenna, do ktorej sa budu ukladat cisla, aby ich bolo mozne vypisat ako char* */
          char tmp_str[2];
          /* Pridanie terminatora. */
          tmp_str[1] = '\0';
          /* Zapis samotneho cisla do retazca. */
          tmp_str[0] = history_count + '0';
          
          lcd_print(tmp_str);
          lcd_print(" tip");
        }

        delay(1000);

        finished = true;
      }
      /* Podmienka ak uzivatel prehral. */
      else if(history_count >= 10) {
        lcd_print_at(0,3, "YOU LOST");
        lcd_print_at(1,0, "Correct is ");
        lcd_print(secret);
        
        delay(1000);

        finished = true;        
      }
    }

    /* Vycistenie historie, aby nezostalo nic nepotrebne v pamati. */
    for(int index = 0; index < history_count; index++) {
      free(history[index]);
    }

    /* Cakanie, dokym uzivatel nestlaci enter. */
    while(digitalRead(BTN_ENTER_PIN) != HIGH) {
      delay(10);
    }
  }
}
